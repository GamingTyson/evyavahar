<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use Dompdf\Dompdf;
use Dompdf\Options;

require __DIR__ . '/vendor/autoload.php'; // Ensure Dompdf & PHPMailer are loaded

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $data = json_decode(file_get_contents("php://input"), true);
    $email = $data['to'];
    $subject = $data['subject'];
    $body = $data['body'];
    $invoiceHtml = $data['invoiceHtml']; // Get invoice HTML from frontend

    // Initialize Dompdf
    $options = new Options();
    $options->set('isHtml5ParserEnabled', true);
    $dompdf = new Dompdf($options);
    
    // Load HTML into Dompdf
    $dompdf->loadHtml($invoiceHtml);
    $dompdf->setPaper('A4', 'portrait'); // Set PDF size
    $dompdf->render();
    
    // Save the PDF to a file
    $pdfPath = __DIR__ . "/invoice.pdf";
    file_put_contents($pdfPath, $dompdf->output());

    // Initialize PHPMailer
    $mail = new PHPMailer(true);
    try {
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'jesvinblaze@gmail.com';  // Your Gmail
        $mail->Password = 'zggp xgla pgpk qkwy';  // Use your new App Password
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;

        $mail->setFrom('jesvinblaze@example.com', 'Your Name');
        $mail->addAddress($email);
        $mail->isHTML(true);
        $mail->Subject = $subject;
        $mail->Body = $body;

        // Attach the generated PDF
        $mail->addAttachment($pdfPath, "Invoice.pdf");

        if ($mail->send()) {
            echo json_encode(["status" => "success", "message" => "Email with PDF sent successfully!"]);
        } else {
            echo json_encode(["status" => "error", "message" => "Failed to send email."]);
        }

        // Delete the generated PDF after sending
        unlink($pdfPath);
    } catch (Exception $e) {
        echo json_encode(["status" => "error", "message" => "Mailer Error: {$mail->ErrorInfo}"]);
    }
}
?>
