function toggleDropdown(dropdownId) {
    const dropdown = document.getElementById(dropdownId);
    dropdown.classList.toggle('hidden');
}

function showNewSalesPage() {
    document.querySelector('.main-content').classList.add('hidden');
    document.getElementById('newSalesPage').classList.remove('hidden');
    fetch('sales-invoice.html')
        .then(response => response.text())
        .then(data => {
            document.getElementById('sales-invoice-content').innerHTML = data;
        });
}

// Function to add a new item row dynamically
function addItemRow() {
    const row = document.createElement('tr');
    row.innerHTML = `
        <td class="border px-4 py-2"><input type="text" class="w-full border-gray-300 rounded-md" /></td>
        <td class="border px-4 py-2"><input type="text" class="w-full border-gray-300 rounded-md" /></td>
        <td class="border px-4 py-2"><input type="number" class="w-full border-gray-300 rounded-md" oninput="calculateTotals()" /></td>
        <td class="border px-4 py-2"><input type="number" class="w-full border-gray-300 rounded-md" oninput="calculateTotals()" /></td>
        <td class="border px-4 py-2"><input type="number" class="w-full border-gray-300 rounded-md" oninput="calculateTotals()" /></td>
        <td class="border px-4 py-2"><input type="number" class="w-full border-gray-300 rounded-md" oninput="calculateTotals()" /></td>
        <td class="border px-4 py-2"><span class="amount">0.00</span></td>
    `;
    document.getElementById('item-rows').appendChild(row);
}

// Function to calculate total, tax, and grand total dynamically
function calculateTotals() {
    let totalQty = 0;
    let subTotal = 0;
    let discountTotal = 0;
    let taxTotal = 0;

    document.querySelectorAll('#item-rows tr').forEach(row => {
        const inputs = row.querySelectorAll('input');
        const qty = parseFloat(inputs[2].value) || 0;
        const price = parseFloat(inputs[3].value) || 0;
        const discount = parseFloat(inputs[4].value) || 0;
        const tax = parseFloat(inputs[5].value) || 0;

        const lineTotal = qty * price * (1 - discount / 100) * (1 + tax / 100);
        row.querySelector('.amount').innerText = lineTotal.toFixed(2);

        totalQty += qty;
        subTotal += qty * price;
        discountTotal += qty * price * (discount / 100);
        taxTotal += qty * price * (tax / 100);
    });

    const grandTotal = subTotal - discountTotal + taxTotal;

    document.getElementById('total-qty').value = totalQty.toFixed(2);
    document.getElementById('sub-total').value = subTotal.toFixed(2);
    document.getElementById('discount-total').value = discountTotal.toFixed(2);
    document.getElementById('tax-total').value = taxTotal.toFixed(2);
    document.getElementById('grand-total').value = grandTotal.toFixed(2);
}

// Ensure all inputs trigger total calculation
document.addEventListener('DOMContentLoaded', function () {
    document.querySelectorAll('#item-rows input').forEach(input => {
        input.addEventListener('input', calculateTotals);
    });
});

// Function to handle form submission
function handleSubmit(event) {
    event.preventDefault();
    calculateTotals();
    alert('Form submitted successfully!');
}

// Function to print the invoice with user input values (without buttons)
function printInvoice() {
    var invoiceSection = document.getElementById('printable-area').cloneNode(true);

    // Remove buttons and elements with "no-print" class
    invoiceSection.querySelectorAll(".no-print").forEach(el => el.remove());

    // Convert input fields, textareas, and selects to plain text
    invoiceSection.querySelectorAll("input, textarea, select").forEach(el => {
        var span = document.createElement("span");
        span.textContent = el.value || "-";
        span.style.fontWeight = "bold"; 
        el.replaceWith(span);
    });

    var printWindow = window.open("", "", "width=800, height=600");
    printWindow.document.write(`
        <html>
        <head>
            <title>Print Invoice</title>
            <style>
                body { font-family: Arial, sans-serif; padding: 20px; }
                table { width: 100%; border-collapse: collapse; margin-top: 20px; }
                th, td { border: 1px solid black; padding: 8px; text-align: left; }
                th { background-color: #f2f2f2; }
                .align-right { text-align: right; }
            </style>
        </head>
        <body>
            ${invoiceSection.innerHTML}
        </body>
        </html>
    `);
    printWindow.document.close();
    printWindow.print();
}

// Function to send email with invoice as PDF (without buttons)
async function sendEmail() {
    const email = document.getElementById('email').value;
    if (!email) {
        alert('Please enter an email address.');
        return;
    }

    // Clone invoice section and remove buttons before sending
    let invoiceClone = document.getElementById('printable-area').cloneNode(true);
    invoiceClone.querySelectorAll(".no-print").forEach(el => el.remove());

    // Convert input fields to plain text
    invoiceClone.querySelectorAll("input, textarea").forEach(input => {
        let span = document.createElement("span");
        span.textContent = input.value || "-";
        input.replaceWith(span);
    });

    // Get the final invoice HTML with all values
    const invoiceHtml = invoiceClone.innerHTML;

    // Prepare email data
    const emailData = {
        to: email,
        subject: `Invoice ${document.getElementById('invoice').value}`,
        body: `<p>Dear ${document.getElementById('customer').value},</p><p>Please find your invoice attached.</p>`,
        invoiceHtml: invoiceHtml
    };

    try {
        const response = await fetch('send_email.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(emailData)
        });

        const result = await response.json();
        if (response.ok) {
            alert(`Invoice sent to ${email}`);
        } else {
            alert(`Failed to send email: ${result.message}`);
        }
    } catch (error) {
        alert(`Error: ${error.message}`);
    }
}

// Initialize the sales vs purchase chart
const ctx = document.getElementById('salesPurchaseChart').getContext('2d');
const salesPurchaseChart = new Chart(ctx, {
    type: 'bar',
    data: {
        labels: ['January', 'February', 'March', 'April', 'May', 'June', 'July'],
        datasets: [{
            label: 'Sales',
            data: [12, 19, 3, 5, 2, 3, 7],
            backgroundColor: 'rgba(75, 192, 192, 0.2)',
            borderColor: 'rgba(75, 192, 192, 1)',
            borderWidth: 1
        }, {
            label: 'Purchase',
            data: [2, 3, 20, 5, 1, 4, 10],
            backgroundColor: 'rgba(247, 153, 110, 0.2)',
            borderColor: 'rgb(255, 102, 102)',
            borderWidth: 1
        }]
    },
    options: {
        scales: {
            y: {
                beginAtZero: true
            }
        }
    }
});
